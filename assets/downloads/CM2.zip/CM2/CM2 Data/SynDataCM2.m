%% Synthetic Data Generator

%% aliquot 1

% inputs
sampleName = 'CM2';
fractionType = 'z';
numFractions = 15;  fractionsV = [1 numFractions];
numRatios = 150;
%important numbers
age206_238r = 70.55 *10^6;   %in millions of years
age207_235r = 70.58 *10^6;
cps205 = 100000; %add in uniform distribution noise
pbBlankMassInGrams = 0.6 * 10^-12; %add uniform distribution noise
radToCommon206 = 4000;   %add in uniform distrubution noise
r208_206r = 0.15;   %add variation
%tracer
r204_205t  = 0.00009148228911817890;
r206_205t  = 0.00034401000000000000;
r207_205t  = 0.00027841534477177100;
r208_205t  = 0.00068387571317814000;
r233_235t  = 0.99464000000000000000;
r238_235t  = 0.00310363548620606000;
concPb205t = 0.00000000000988366856;
concU235t  = 0.00000000099014621674;
%blank
alphaPb = 0.0025; %add variation, and below
alphaU = 0.001;
r206_204b = 18.241;
r207_204b = 15.339;
r208_204b = 37.354;
blankmu = [r206_204b r207_204b r208_204b]; %206/204 207/204 208/204
blankstd = [0.21 0.15 0.50]; 
blankrhos = [0.78 0.87 0.89];
uBlankMassInGrams = 0.1*10^-12;

%physical constants
lambda235 = 0.00000000098485;
lambda238 = 0.000000000155125;
gmol204 = 203.973028;
gmol205 = 204.9737;
gmol206 = 205.974449;
gmol207 = 206.975880;
gmol208 = 207.976636;
gmol235 = 235.043922;
gmol238 = 238.050785;
%others
tracerMassInGrams = 0.01; %add variation
r238_235s = 137.88;
r238_235b = 137.88;
r18O_16O = 0.00205;

%% Add in the random variations

tracerMassInGramsV = tracerMassInGrams + 0.004*(rand(fractionsV)-0.5);
cps205V = cps205/tracerMassInGrams * tracerMassInGramsV;
pbBlankMassInGramsV = pbBlankMassInGrams + 0.4*10^-12*(rand(fractionsV)-0.5); %in grams
radToCommon206V = radToCommon206 + 5000*(rand(fractionsV)-0.5);
alphaPbV = alphaPb + 0.0002*randn(fractionsV);
alphaUV  = alphaU  + 0.0001*randn(fractionsV);

blankcovmatdiag = diag(blankstd.^2);
blankcovmatndia = [0 blankrhos(1)*blankstd(1)*blankstd(2)...
    blankrhos(2)*blankstd(1)*blankstd(3); 0 0 blankrhos(3)*blankstd(2)*blankstd(3);...
    0 0 0];
blankcovmat = blankcovmatdiag + blankcovmatndia + blankcovmatndia';
blanks = mvnrnd(blankmu, blankcovmat, numFractions);
r206_204bV=blanks(:,1)'; r207_204bV=blanks(:,2)'; r208_204bV=blanks(:,3)';

r208_206rV = r208_206r + 0.3*(rand(fractionsV)-.5);
uBlankMassInGramsV = uBlankMassInGrams+ 0.01*10^-12*(randn(fractionsV));
r238_235bV = r238_235b + 0.01*(randn(fractionsV));
r238_235sV = r238_235s + 0.01*(randn(fractionsV));
r18O_16OV = r18O_16O + 0.00002*(randn(fractionsV));

%% CALCULATE INTERMEDIATE VALUES
r206_238r = exp(lambda238*age206_238r)-1;
r207_235r = exp(lambda235*age207_235r)-1;
r207_206r = (exp(lambda235*age207_235r)-1)/(r238_235s*(exp(lambda238*age206_238r)-1));

blankPbGramsMol = gmol204+r206_204b*gmol206+r207_204b*gmol207+r208_204b*gmol208;
molPb204bV = pbBlankMassInGramsV/blankPbGramsMol;
molPb206bV = r206_204bV .* molPb204bV;
molPb207bV = r207_204bV .* molPb204bV;
molPb208bV = r208_204bV .* molPb204bV;
molPb205tV = concPb205t*tracerMassInGramsV;
r204_205fcV = (molPb204bV + molPb205tV.*r204_205t)./molPb205tV;

molPb206rV = molPb204bV .* radToCommon206V;
molU238sV = molPb206rV ./ r206_238r;
molU235sV = molU238sV ./ r238_235sV;
molPb207rV = molPb206rV * r207_206r;
molPb208rV = molPb206rV .* r208_206rV;

r206_205mV = (molPb206bV+molPb206rV+molPb205tV*r206_205t)./((1+alphaPbV).*molPb205tV);
r207_205mV = (molPb207bV+molPb207rV+molPb205tV*r207_205t)./((1+2*alphaPbV).*molPb205tV);
r208_205mV = (molPb208rV ./ molPb205tV) ./ (1+2*alphaPbV);
r204_205mV = r204_205fcV ./ (1-alphaPbV);

molU235bV = uBlankMassInGramsV ./ (gmol235+r238_235bV*gmol238);
molU238bV = r238_235bV .* molU235bV;
molU235tV = concU235t * tracerMassInGramsV;
molU238tV = r238_235t * molU235tV;
molU233tV = r233_235t * molU235tV;
r233_235ocV = molU233tV./((1-2*alphaUV).*(molU235tV+molU235bV+molU235sV));
r238_235ocV = (molU238tV+molU238bV+molU238sV)./(molU235tV+molU235bV+molU235sV)./(1+3*alphaUV);
r270_267mV = r238_235ocV ./ (1+2*r18O_16OV.*r233_235ocV);
r265_267mV = r233_235ocV ./ (1+2*r18O_16OV.*r233_235ocV);

%% Add in measured ratio noise
for i = 1:numFractions
    cps205 = poissrnd(5 *cps205V(i)           ,numRatios,1)/5;
    cps204 = poissrnd(10*r204_205mV(i)*cps205 ,numRatios,1)/10;
    cps206 = poissrnd(5 *r206_205mV(i)*cps205 ,numRatios,1)/5;
    cps207 = poissrnd(5 *r207_205mV(i)*cps205 ,numRatios,1)/5;
    cps208 = poissrnd(5 *r208_205mV(i)*cps205 ,numRatios,1)/5;
    cps270 = poissrnd(5 *cps206/r206_238r     ,numRatios,1)/5;
    cps267 = poissrnd(5 *cps270/r270_267mV(i) ,numRatios,1)/5;
    cps265 = poissrnd(5 *cps267*r265_267mV(i) ,numRatios,1)/5;
    r206_204mR = cps206./cps204;
    r207_204mR = cps207./cps204;
    r208_204mR = cps208./cps204;
    r206_207mR = cps206./cps207;
    r206_208mR = cps206./cps208;
    r204_205mR = cps204./cps205;
    r206_205mR = cps206./cps205;
    r207_205mR = cps207./cps205;
    r208_205mR = cps208./cps205;
    r270_267mR = cps270./cps267;
    r265_267mR = cps265./cps267;
    allRatiosPb = [r206_204mR r207_204mR r208_204mR r206_207mR r206_208mR ...
        r204_205mR r206_205mR r207_205mR r208_205mR];
    pbRatiosString = {'206/204', '207/204', '208/204', '206/207', '206/208',...
        '204/205', '206/205', '207/205', '208/205'};
    allRatiosU = [r270_267mR r265_267mR];
    uRatiosString = {'270/267', '265/267'};
    assignin('base',[sampleName '_' fractionType num2str(i) 'Pb'], allRatiosPb);
    assignin('base',[sampleName '_' fractionType num2str(i) 'U' ], allRatiosU);
    
    xlsStringPb = [sampleName '_' fractionType num2str(i) '_Pb.xls'];
    xlsStringU = [sampleName '_' fractionType num2str(i) '_U.xls'];
    xlswrite(xlsStringPb, allRatiosPb, 'Cycle', 'C17:K167');
    xlswrite(xlsStringPb, pbRatiosString, 'Cycle', 'C2:K2');
    xlswrite(xlsStringPb, numRatios, 'CTRL', 'D17');
    xlswrite(xlsStringPb, size(allRatiosPb,2), 'CTRL', 'B12');
    xlswrite(xlsStringPb, 10, 'CTRL', 'D13');
    xlswrite(xlsStringU , allRatiosU , 'Cycle', 'C17:D167');
    xlswrite(xlsStringU , uRatiosString,  'Cycle', 'C2:D2');
    xlswrite(xlsStringU, numRatios, 'CTRL', 'D17');
    xlswrite(xlsStringU, size(allRatiosU,2), 'CTRL', 'B12');
    xlswrite(xlsStringU, 10, 'CTRL', 'D13');    
end
xlswrite('TracerMasses.xls',tracerMassInGramsV');